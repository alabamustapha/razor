<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Création de compte Résidassur.fr</title>
</head>
<body>
<img style="width: 300px;" src="<?php echo e(asset('../images/logo.png')); ?>" alt="">
<br>
<br>
<br>
<h2>Bonjour <?php echo e($user->aff_lname); ?> <?php echo e($user->aff_fname); ?>,</h2>
Votre compte a été créé avec succès.
<br>
Votre compte demeure inactif environ 48h tant que l'administrateur du site n'a pas validé et activé votre compte. Vous êtes prévenu(e) par e-mail lorsque votre compte est activé.
<br>
<br>
<br>
<br>
L'équipe CORIM ASSURANCE
</body>
</html>