<?php

namespace App\Models;

use Codedge\Fpdf\Fpdf\Fpdf;
use Illuminate\Database\Eloquent\Model;

class FpdfOldAutorisation extends Fpdf
{
    public function header(){

    }
    function Table_entete($data)
    {

    }

    public function footer(){

    }
}
